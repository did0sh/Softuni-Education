package p01_DefineClassPerson;

public class Person {
    private String name;
    private int age;
}
