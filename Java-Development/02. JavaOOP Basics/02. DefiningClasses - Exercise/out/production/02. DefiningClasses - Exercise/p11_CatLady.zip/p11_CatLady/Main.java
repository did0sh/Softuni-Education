package p11_CatLady;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedHashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String input = reader.readLine();
        Map<String, Cat> cats = new LinkedHashMap<>();

        while (!"end".equalsIgnoreCase(input)){
            String[] info = input.split("\\s+");
            String type = info[0];
            String name = info[1];
            int num = Integer.parseInt(info[2]);

            switch (type){
                case "Cymric":
                    Cymric cymricCat = new Cymric(name, num);
                    cats.put(name, cymricCat);
                    break;
                case "StreetExtraordinaire":
                    StreetExtraordinaire cat = new StreetExtraordinaire(name, num);
                    cats.put(name, cat);
                    break;
                case "Siamese":
                    Siamese siameseCat = new Siamese(name, num);
                    cats.put(name, siameseCat);
                    break;
            }
            input = reader.readLine();
        }

        input = reader.readLine();
        for (Map.Entry<String, Cat> stringCatEntry : cats.entrySet()) {
            if (stringCatEntry.getKey().equals(input)){
                System.out.print(stringCatEntry.getValue());
            }
        }
    }
}
