package p02_MultiLevelInheritance;

public class Animal {
    public void eat(){
        System.out.println("eating...");
    }
}
