package p04_FragileBaseClass;

public class Food {
}
