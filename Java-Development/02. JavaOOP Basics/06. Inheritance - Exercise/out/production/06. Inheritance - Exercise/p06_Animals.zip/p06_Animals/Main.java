package p06_Animals;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        StringBuilder sb = new StringBuilder();
        while (true){
            String type = reader.readLine();
            if (type.equalsIgnoreCase("beast!")){
                break;
            }
            String[] info = reader.readLine().split("\\s+");
            try {
                String name = info[0];
                int age = Integer.parseInt(info[1]);
                String gender = info[2];
                switch (type.toLowerCase()){
                    case "cat":
                        Cat cat = new Cat(name, age, gender);
                      appendResultToBuilder(sb, cat);
                        sb.append(cat.getName()).append(" ")
                                .append(cat.getAge()).append(" ")
                                .append(cat.getGender()).append(System.lineSeparator())
                                .append(cat.produceSound()).append(System.lineSeparator());
                        break;
                    case "dog":
                        Dog dog = new Dog(name,age,gender);
                        appendResultToBuilder(sb, dog);
                        sb.append(dog.getName()).append(" ")
                                .append(dog.getAge()).append(" ")
                                .append(dog.getGender()).append(System.lineSeparator())
                                .append(dog.produceSound()).append(System.lineSeparator());
                        break;
                    case "frog":
                        Frog frog = new Frog(name,age,gender);
                        appendResultToBuilder(sb, frog);
                        sb.append(frog.getName()).append(" ")
                                .append(frog.getAge()).append(" ")
                                .append(frog.getGender()).append(System.lineSeparator())
                                .append(frog.produceSound()).append(System.lineSeparator());
                        break;
                    case "kitten":
                        Kitten kitten = new Kitten(name,age,gender);
                        appendResultToBuilder(sb,kitten);
                        sb.append(kitten.getName()).append(" ")
                                .append(kitten.getAge()).append(" ")
                                .append(kitten.getGender()).append(System.lineSeparator())
                                .append(kitten.produceSound()).append(System.lineSeparator());
                        break;
                    case "tomcat":
                        Tomcat tomcat = new Tomcat(name,age,gender);
                        appendResultToBuilder(sb,tomcat);
                        sb.append(tomcat.getName()).append(" ")
                                .append(tomcat.getAge()).append(" ")
                                .append(tomcat.getGender()).append(System.lineSeparator())
                                .append(tomcat.produceSound()).append(System.lineSeparator());
                        break;
                }
            } catch (IllegalArgumentException iae){
                System.out.println(iae.getMessage());
            }
        }

        System.out.print(sb);
    }

    private static void appendResultToBuilder(StringBuilder sb, Object object) {
        sb.append(object.getClass().getSimpleName())
                .append(System.lineSeparator());
    }

}
