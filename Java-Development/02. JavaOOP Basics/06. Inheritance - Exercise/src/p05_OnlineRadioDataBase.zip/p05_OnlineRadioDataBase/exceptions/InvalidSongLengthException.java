package p05_OnlineRadioDataBase.exceptions;

public class InvalidSongLengthException extends InvalidSongException {

    public InvalidSongLengthException(String message) {
        super(message);
    }
}
