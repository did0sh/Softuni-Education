package p03_CarShopExtended;

public interface Sellable extends Car {
    Double getPrice();
}
