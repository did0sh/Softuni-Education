package p09_CollectionHierarchy;

public interface Addable {
    int add(String element);
}
