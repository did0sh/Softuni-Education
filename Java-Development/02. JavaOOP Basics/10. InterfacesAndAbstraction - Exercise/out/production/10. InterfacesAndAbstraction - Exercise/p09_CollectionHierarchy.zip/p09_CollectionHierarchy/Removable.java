package p09_CollectionHierarchy;

public interface Removable {
    String remove();
}
