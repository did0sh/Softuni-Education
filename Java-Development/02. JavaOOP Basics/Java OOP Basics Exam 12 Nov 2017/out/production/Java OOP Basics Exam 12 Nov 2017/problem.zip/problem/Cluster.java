package problem;

import java.util.*;

public class Cluster {
    private String id;
    private int rows;
    private int cols;
    private Set<String> allIds;
    private Map<String, List<Cell>> cells;

    public Cluster(String id, int rows, int cols) {
        this.setId(id);
        this.setRows(rows);
        this.setCols(cols);
        this.cells = new LinkedHashMap<>();
        this.allIds = new LinkedHashSet<>();
        this.addId();
    }

    private void setId(String id) {
        this.id = id;
    }

    private void setRows(int rows) {
        if (rows >= 0){
            this.rows = rows;
        }
    }

    private void setCols(int cols) {
        if (cols >= 0){
            this.cols = cols;
        }
    }

    public String getId() {
        return this.id;
    }

    public int getRows() {
        return this.rows;
    }

    public int getCols() {
        return this.cols;
    }

    private void addId(){
        this.allIds.add(this.getId());
    }

    public Map<String,List<Cell>> getCells() {
        return this.cells;
    }


    public void addCell(Cell cell){
        for (String allId : allIds) {
            if (!this.cells.containsKey(allId)){
                this.cells.put(allId, new ArrayList<>());
            }

            this.cells.get(allId).add(cell);
        }
    }

    @Override
    public String toString() {
        return null;
    }

}
