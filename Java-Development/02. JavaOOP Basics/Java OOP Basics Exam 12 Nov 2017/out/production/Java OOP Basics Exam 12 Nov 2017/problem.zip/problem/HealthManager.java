package problem;

import problem.cellTypes.RedBloodCell;
import problem.cellTypes.WhiteBloodCell;
import problem.microbeTypes.Bacteria;
import problem.microbeTypes.Fungi;
import problem.microbeTypes.Virus;

import java.util.*;
import java.util.stream.Collectors;

public class HealthManager {
    private Map<String, Organism> organisms;

    public HealthManager() {
        this.organisms = new LinkedHashMap<>();
    }

    public String checkCondition(String organismName) {
        StringBuilder sb = new StringBuilder();
        if (this.organisms.containsKey(organismName)) {
            Organism organism = this.organisms.get(organismName);

            sb.append(String.format("Organism - %s%n", organism.getName()))
                    .append(String.format("--Clusters: %d%n", organism.getClusters().size()))
                    .append(String.format("--Cells: %d%n", organism.getClusters()
                            .stream().mapToInt(cluster -> cluster.getCells().size()).sum()));

            organism.getClusters().forEach(cluster -> {
                sb.append(String.format("----Cluster %s%n", cluster.getId()));
                cluster.getCells().entrySet().forEach(c1 -> {
                    c1.getValue().stream().sorted(Comparator.comparing(Cell::getPositionRow).thenComparing(Cell::getPositionCol))
                            .forEach(cell -> {
                                sb.append(String.format("------Cell %s [%d,%d]%n",
                                        cell.getId(), cell.getPositionRow(), cell.getPositionCol()));

                                if (cell.getClass().getSimpleName().equals("WhiteBloodCell")) {
                                    sb.append(String.format("--------Health: %d | Size: %d | Energy: %d%n",
                                            cell.getHealth(), cell.size(), cell.energy()));
                                } else if (cell.getClass().getSimpleName().equals("RedBloodCell")) {
                                    sb.append(String.format("--------Health: %d | Velocity: %d | Energy: %d%n",
                                            cell.getHealth(), cell.velocity(), cell.energy()));
                                } else if (cell.getClass().getSimpleName().equals("Fungi")
                                        || cell.getClass().getSimpleName().equals("Bacteria")
                                        || cell.getClass().getSimpleName().equals("Virus")) {
                                    sb.append(String.format("--------Health: %d | Virulence: %d | Energy: %d%n",
                                            cell.getHealth(), cell.virulence(), cell.energy()));
                                }
                            });
                });
            });
            return sb.toString();
        }

        return null;
    }


    public String createOrganism(String name) {
        if (!this.organisms.containsKey(name)) {
            Organism organism = new Organism(name);
            this.organisms.put(name, organism);
            return String.format("Created organism %s%n", name);
        }

        return String.format("Organism %s already exists%n", name);

    }

    public String addCluster(String organismName, String id, int rows, int cols) {
        Cluster cluster = new Cluster(id, rows, cols);

        if (this.organisms.containsKey(organismName)) {
            List<Cluster> filtered = this.organisms.get(organismName).getClusters()
                    .stream().filter(cluster1 -> cluster1.getId().equals(id)).collect(Collectors.toList());

            if (filtered.size() == 0) {
                this.organisms.get(organismName).addCluster(cluster);
                return String.format("Organism %s: Created cluster %s%n", organismName, id);
            }
        }
        return null;
    }

    public String addCell(String organismName, String clusterId, String cellType, String cellId
            , int health, int positionRow, int positionCol, int additionalProperty) {

        Cell cell = null;
        switch (cellType) {
            case "RedBloodCell":
                if (positionCol >= 0 && positionRow >= 0) {
                    cell = new RedBloodCell(cellId, health, positionRow, positionCol, additionalProperty);
                    break;
                }
            case "WhiteBloodCell":
                if (positionCol >= 0 && positionRow >= 0) {
                    cell = new WhiteBloodCell(cellId, health, positionRow, positionCol, additionalProperty);
                    break;
                }
            case "Bacteria":
                if (positionCol >= 0 && positionRow >= 0) {
                    cell = new Bacteria(cellId, health, positionRow, positionCol, additionalProperty);
                    break;
                }
            case "Fungi":
                if (positionCol >= 0 && positionRow >= 0) {
                    cell = new Fungi(cellId, health, positionRow, positionCol, additionalProperty);
                    break;
                }
            case "Virus":
                if (positionCol >= 0 && positionRow >= 0) {
                    cell = new Virus(cellId, health, positionRow, positionCol, additionalProperty);
                    break;
                }
        }

        if (this.organisms.containsKey(organismName)) {
            List<Cluster> filtered = this.organisms.get(organismName).getClusters()
                    .stream().filter(cluster -> cluster.getId().equals(clusterId)).collect(Collectors.toList());
            if (filtered.size() > 0) {
                Cell finalCell = cell;
                filtered.forEach(cluster -> cluster.addCell(finalCell));
                return String.format("Organism %s: Created cell %s in cluster %s%n", organismName,
                        cellId, clusterId);
            }
        }

        return null;
    }

    public String activateCluster(String organismName) {
        if (!this.organisms.containsKey(organismName) || this.organisms.get(organismName).getClusters().size() < 1) {
            return null;
        }
        int index = 0;
        String id = null;
        try {
            for (int i = 0; i < this.organisms.get(organismName).getClusters().size(); i++) {
                Cluster cluster1 = this.organisms.get(organismName).getClusters().get(i);
                id = cluster1.getId();
                index = i;

                List<Cell> sorted = new ArrayList<>();

                cluster1.getCells().entrySet().forEach(c1 -> {
                    c1.getValue().stream().sorted(Comparator.comparing(Cell::getPositionRow).thenComparing(Cell::getPositionCol))
                            .forEach(sorted::add);
                });

                for (i = 1; i < sorted.size(); i++) {
                    if (sorted.get(0) instanceof BloodCell) {
                        sorted.get(0).setHealth(sorted.get(0).getHealth() + sorted.get(i).getHealth());
                        sorted.get(0).setPositionRow(sorted.get(i).getPositionRow());
                        sorted.get(0).setPositionCol(sorted.get(i).getPositionCol());
                    } else {
                        while (true) {
                            sorted.get(i).setHealth(sorted.get(i).getHealth() - sorted.get(0).energy());
                            if (sorted.get(i).getHealth() <= 0) {
                                sorted.get(0).setPositionRow(sorted.get(i).getPositionRow());
                                sorted.get(0).setPositionCol(sorted.get(i).getPositionCol());
                                break;
                            }
                            sorted.get(0).setHealth(sorted.get(0).getHealth() - sorted.get(i).energy());
                            if (sorted.get(0).getHealth() <= 0) {
                                sorted.set(0, sorted.get(i));
                                break;
                            }
                        }
                    }
                }
                cluster1.getCells().clear();
                cluster1.addCell(sorted.get(0));
                break;
            }
        } catch (Exception e){ }

        Cluster cluster = this.organisms.get(organismName).getClusters().get(index);
        int finalIndex = index;
        String finalId = id;
        this.organisms.get(organismName).getClusters().forEach(cl -> cl.getCells().remove(finalIndex));
        int size = cluster.getCells().size();
        return String.format("Organism %s: Activated cluster %s. Cells left: %d%n", organismName, cluster.getId(), size);
    }

}
