package problem;

import java.util.*;

public class Organism {
    private String name;
    private List<Cluster> clusters;

    public Organism(String name) {
        this.name = name;
        this.clusters = new ArrayList<>();
    }


    public String getName() {
        return this.name;
    }

    public List<Cluster> getClusters() {
        return this.clusters;
    }

    public void addCluster(Cluster cluster){
        this.clusters.add(this.clusters.size(),cluster);
    }


    @Override
    public String toString() {
        return null;
    }
}
