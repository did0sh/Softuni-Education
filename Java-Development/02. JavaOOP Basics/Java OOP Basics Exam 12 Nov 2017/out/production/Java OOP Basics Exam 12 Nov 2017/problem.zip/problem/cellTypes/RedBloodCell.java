package problem.cellTypes;

import problem.BloodCell;

public class RedBloodCell extends BloodCell {
    private int velocity;
    public RedBloodCell(String id, int health, int positionRow, int positionCol, int velocity) {
        super(id, health, positionRow, positionCol);
        this.setVelocity(velocity);
    }

    private void setVelocity(int velocity) {
        if (velocity >= 0){
            this.velocity = velocity;
        }
    }

    @Override
    public int energy() {
        int energy = 0;
        return energy = this.getHealth() + this.velocity();
    }

    @Override
    public int velocity() {
        return this.velocity;
    }
}
