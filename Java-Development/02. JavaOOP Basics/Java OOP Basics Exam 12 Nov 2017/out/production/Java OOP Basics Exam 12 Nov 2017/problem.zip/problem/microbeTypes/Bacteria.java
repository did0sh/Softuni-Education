package problem.microbeTypes;

import problem.Microbe;

public class Bacteria extends Microbe {
   public Bacteria(String id, int health, int positionRow, int positionCol, int virulence){
       super(id, health, positionRow, positionCol, virulence);
   }

    @Override
    public int virulence() {
        return super.getVirulence();
    }


    @Override
    public int energy() {
        int energy = 0;
        return energy = (this.getHealth() + this.virulence()) /3;
    }
}
