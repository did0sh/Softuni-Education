package exam;

public abstract class Monument {
    private String name;

    public Monument(String name) {
        this.name = name;
    }
}
