package exam;

import java.util.ArrayList;
import java.util.Collection;

public class Nation {
    private Collection<Bender> nations;

    public Nation() {
        this.nations = new ArrayList<>();
    }
}
