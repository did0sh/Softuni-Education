package exam.benders;

import exam.Bender;

public class AirBender extends Bender {
    private double aerialIntegrity;
    public AirBender(String name, int power, double aerialIntegrity) {
        super(name, power);
        this.aerialIntegrity = aerialIntegrity;
    }
}
