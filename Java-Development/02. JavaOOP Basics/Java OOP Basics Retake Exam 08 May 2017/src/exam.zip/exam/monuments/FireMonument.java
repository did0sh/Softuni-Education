package exam.monuments;

import exam.Monument;

public class FireMonument extends Monument {
    private int fireAffinity;
    public FireMonument(String name, int fireAffinity) {
        super(name);
        this.fireAffinity = fireAffinity;
    }
}
