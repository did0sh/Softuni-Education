package p02_WarningLevels;

public enum Importance {
    LOW, NORMAL, MEDIUM, HIGH;
}
