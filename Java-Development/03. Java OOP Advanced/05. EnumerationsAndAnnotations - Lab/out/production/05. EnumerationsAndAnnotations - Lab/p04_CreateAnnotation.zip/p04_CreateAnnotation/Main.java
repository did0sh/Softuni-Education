package p04_CreateAnnotation;

public class Main {
}
