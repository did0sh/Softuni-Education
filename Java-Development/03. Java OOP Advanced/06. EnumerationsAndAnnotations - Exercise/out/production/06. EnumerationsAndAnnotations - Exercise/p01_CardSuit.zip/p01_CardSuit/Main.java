package p01_CardSuit;

public class Main {
    public static void main(String[] args) {
        System.out.println("Card Suits:");
        for (CardType cardType : CardType.values()) {
            System.out.println(cardType);
        }
    }
}
