package p09_TrafficLights;

public enum Signal {
    RED, GREEN, YELLOW;
}
