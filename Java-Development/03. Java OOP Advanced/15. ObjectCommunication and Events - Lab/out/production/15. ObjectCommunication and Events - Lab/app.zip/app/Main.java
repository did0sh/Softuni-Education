package app;

import app.commands.AttackCommand;
import app.commands.CommandExecutor;
import app.commands.TargetCommand;
import app.interfaces.Attacker;
import app.interfaces.Command;
import app.interfaces.Executor;
import app.interfaces.Target;
import app.abstractModels.AbstractLogger;
import app.loggers.CombatLogger;
import app.loggers.ErrorLogger;
import app.abstractModels.AbstractHero;
import app.enums.LogType;
import app.loggers.EventLogger;
import app.models.Dragon;
import app.models.Warrior;

import java.util.logging.Logger;

public class Main {
    public static void main(String[] args) {
        AbstractLogger combatLog = new CombatLogger();
        AbstractLogger eventLog = new EventLogger();

        combatLog.setSuccessor(eventLog);

        Attacker warrior = new Warrior("warrior", 10, combatLog);
        Target dragon = new Dragon("dragon", 100, 25, combatLog);

        Executor executor = new CommandExecutor();
        Command target = new TargetCommand(warrior, dragon);
        Command attack = new AttackCommand(warrior);

        executor.executeCommand(target);
        executor.executeCommand(attack);
    }
}
