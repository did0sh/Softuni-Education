package app.interfaces;

public interface Attacker {
    void attack();
    void setTarget(Target target);
}
