package app.interfaces;

public interface Command {
    void execute();
}
