package app.interfaces;

public interface Executor {
    void executeCommand(Command command);
}
