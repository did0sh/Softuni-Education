package app.interfaces;

public interface ObservableTarget extends Subject, Target {
}
