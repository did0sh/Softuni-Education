package app.interfaces;

public interface Observer {
    void update(int reward);
}
