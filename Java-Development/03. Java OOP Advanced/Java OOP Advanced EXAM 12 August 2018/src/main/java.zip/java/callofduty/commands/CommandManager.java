package callofduty.commands;

import callofduty.core.MissionControlImpl;
import callofduty.domain.agents.MasterAgent;
import callofduty.domain.agents.NoviceAgent;
import callofduty.domain.missions.EscortMission;
import callofduty.domain.missions.HuntMission;
import callofduty.domain.missions.SurveillanceMission;
import callofduty.interfaces.Agent;
import callofduty.interfaces.Mission;
import callofduty.interfaces.MissionManager;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class CommandManager implements MissionManager {
    private Map<String, Agent> agentMap;
    private MissionControlImpl missionControl;

    public CommandManager() {
        this.agentMap = new LinkedHashMap<>();
        this.missionControl = new MissionControlImpl();
    }

    @Override
    public String agent(List<String> arguments) {
        String id = arguments.get(1);
        String name = arguments.get(2);
        Agent agent = new NoviceAgent(id,name,0.0);
        this.agentMap.put(id, agent);
        return String.format("Registered Agent - %s:%s", name, id);
    }

    @Override
    public String request(List<String> arguments) {
        String agentId = arguments.get(1);
        String missionId = arguments.get(2);
        Double missionRating = Double.parseDouble(arguments.get(3));
        Double missionBounty = Double.parseDouble(arguments.get(4));

        Mission mission = this.missionControl.generateMission(missionId, missionRating, missionBounty);
        this.agentMap.get(agentId).acceptMission(mission);

        if (mission instanceof EscortMission){
            return String.format("Assigned Escort Mission - %s to Agent - %s", missionId,
                    this.agentMap.get(agentId).getName());
        } else if (mission instanceof HuntMission){
            return String.format("Assigned Hunt Mission - %s to Agent - %s", missionId,
                    this.agentMap.get(agentId).getName());
        } else if (mission instanceof SurveillanceMission){
            return String.format("Assigned Surveillance Mission - %s to Agent - %s", missionId,
                    this.agentMap.get(agentId).getName());
        }
        return null;
    }

    @Override
    public String complete(List<String> arguments) {
        String agentId = arguments.get(1);
        this.agentMap.get(agentId).completeMissions(); // TODO;

        return String.format("Agent - %s:%s has completed all assigned missions.",
                this.agentMap.get(agentId).getName(), agentId);
    }

    @Override
    public String status(List<String> arguments) {
        String id = arguments.get(1);
        if (this.agentMap.containsKey(id)){
            return this.agentMap.get(id).toString();
        }

        try {
            Class<Agent> agentClass  = (Class<Agent>) Class.forName("callofduty.domain.agents.AbstractAgent");
            Field missionMapField = agentClass.getField("assignedMissionMap");
            missionMapField.setAccessible(true);

            LinkedHashMap<String, Mission> map = (LinkedHashMap<String, Mission>) missionMapField.get(this.agentMap.get(id));

            if (map.containsKey(id)){
                return map.get(id).toString();
            }
        } catch (ClassNotFoundException | NoSuchFieldException | IllegalAccessException e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    public String over(List<String> arguments) {
        StringBuilder sb = new StringBuilder();
        int assignedMissionsCount = 0;
        int completedMissionsCount = 0;
        try {
            Class<Agent> agentClass = (Class<Agent>) Class.forName("callofduty.domain.agents.AbstractAgent");

            NoviceAgent agent = (NoviceAgent) agentClass.getDeclaredConstructor(String.class, String.class, Double.class).newInstance("asd", "dd", 1.0);
            Field missionMapField = agentClass.getDeclaredField("assignedMissionMap");
            missionMapField.setAccessible(true);

            LinkedHashMap<String, Mission> map = (LinkedHashMap<String, Mission>) missionMapField.get(agent);
            for (Mission value : map.values()) {
                assignedMissionsCount++;
            }

            Class<Agent> agClass = (Class<Agent>) Class.forName("callofduty.domain.agents.AbstractAgent");
            Field completed = agentClass.getField("completedMissionMap");
            missionMapField.setAccessible(true);

            LinkedHashMap<String, Mission> completedMap = (LinkedHashMap<String, Mission>) completed.get(agClass);
            for (Mission value : completedMap.values()) {
                completedMissionsCount++;
            }

        } catch (NoSuchFieldException | ClassNotFoundException | IllegalAccessException | NoSuchMethodException | InstantiationException | InvocationTargetException e) {
            e.printStackTrace();
        }

        double totalRating = this.agentMap.values().stream().mapToDouble(Agent::getRating).sum();
        double totalBounty = this.agentMap.values().stream().filter(agent -> agent instanceof MasterAgent)
                .mapToDouble(a -> (((MasterAgent) a).getBounty())).sum();

        sb.append(String.format("Novice Agents: %d%n", this.agentMap.entrySet().stream().filter(agent ->
                agent.getClass().getSimpleName().equals("NoviceAgent")).collect(Collectors.toList()).size()))
                .append(String.format("Master Agents: %d%n", this.agentMap.entrySet().stream().filter(agent ->
                        agent.getClass().getSimpleName().equals("MasterAgent")).collect(Collectors.toList()).size()))
                .append(String.format("Assigned Missions %d%n", assignedMissionsCount))
                .append(String.format("Completed Missions %d%n", completedMissionsCount))
                .append(String.format("Total Rating Given: %.2f%n", totalRating))
                .append(String.format("Total Bounty Given: %.2f%n", totalBounty));
        return sb.toString().trim();
    }
}
