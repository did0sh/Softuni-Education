package callofduty.engine;

import callofduty.commands.CommandManager;
import callofduty.io.ConsoleReader;
import callofduty.io.ConsoleWriter;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class EngineImpl {
    private ConsoleReader reader;
    private ConsoleWriter writer;
    private CommandManager commandManager;

    public EngineImpl(ConsoleReader reader, ConsoleWriter writer, CommandManager commandManager) {
        this.reader = reader;
        this.writer = writer;
        this.commandManager = commandManager;
    }

    public void run(){
        String input;
        while (true){
            input = this.reader.readLine();
            List<String> commands = Arrays.stream(input.split("\\s+")).collect(Collectors.toList());
            switch (commands.get(0)){
                case "Agent":
                   this.writer.writeLine(this.commandManager.agent(commands));
                    break;
                case "Request":
                    this.writer.writeLine(this.commandManager.request(commands));
                    break;
                case "Status":
                    this.writer.writeLine(this.commandManager.status(commands));
                    break;
                case "Complete":
                    this.writer.writeLine(this.commandManager.complete(commands));
                    break;
            }

            if (commands.get(0).equals("Over")){
                this.writer.writeLine(this.commandManager.over(commands));
                break;
            }
        }
    }
}
