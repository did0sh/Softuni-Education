package callofduty.io;

public class ConsoleWriter {
    public ConsoleWriter(){}

    public void writeLine(String text) {
        System.out.println(text);
    }
}
