package p09_Animals;

import p09_Animals.abstractClasses.BaseAnimal;
import p09_Animals.interfaces.SoundProducable;
import p09_Animals.models.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        List<SoundProducable> allAnimals = new ArrayList<>();

        String input;
        while (true){
            input = scan.nextLine();
            if ("beast!".equalsIgnoreCase(input)){
                break;
            }

            String[] info = scan.nextLine().split("\\s+");
            BaseAnimal animal = null;
            try {
                switch (input){
                    case "Cat":
                        animal = new Cat(info[0], Integer.parseInt(info[1]), info[2]);
                        break;
                    case "Dog":
                        animal = new Dog(info[0], Integer.parseInt(info[1]), info[2]);
                        break;
                    case "Frog":
                        animal= new Frog(info[0], Integer.parseInt(info[1]), info[2]);
                        break;
                    case "Kittens":
                        animal = new Kittens(info[0], Integer.parseInt(info[1]), info[2]);
                        break;
                    case "Tomcat":
                        animal = new Tomcat(info[0], Integer.parseInt(info[1]), info[2]);
                        break;
                    default: throw new IllegalArgumentException("Invalid input!");
                }
                allAnimals.add(animal);
            } catch (IllegalArgumentException iae){
                System.out.println(iae.getMessage());
            }
        }

        for (SoundProducable animal: allAnimals) {
            System.out.println(animal);
            System.out.println(animal.produceSound());
        }
    }
}
