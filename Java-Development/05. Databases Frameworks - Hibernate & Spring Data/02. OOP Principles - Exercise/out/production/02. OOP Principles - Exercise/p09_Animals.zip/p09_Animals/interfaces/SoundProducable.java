package p09_Animals.interfaces;

public interface SoundProducable {
    String produceSound();
}
