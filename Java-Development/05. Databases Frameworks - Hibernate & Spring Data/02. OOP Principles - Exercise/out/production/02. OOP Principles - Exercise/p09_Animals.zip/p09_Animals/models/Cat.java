package p09_Animals.models;

import p09_Animals.abstractClasses.BaseAnimal;

public class Cat extends BaseAnimal {
    public Cat(String name, int age, String gender) {
        super(name, age, gender);
    }

    @Override
    public String produceSound() {
        return "MiauMiau";
    }
}
