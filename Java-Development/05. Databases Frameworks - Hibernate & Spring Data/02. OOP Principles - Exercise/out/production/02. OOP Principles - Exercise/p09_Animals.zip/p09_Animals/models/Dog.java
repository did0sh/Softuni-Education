package p09_Animals.models;

import p09_Animals.abstractClasses.BaseAnimal;

public class Dog extends BaseAnimal {
    public Dog(String name, int age, String gender) {
        super(name, age, gender);
    }

    @Override
    public String produceSound() {
        return "BauBau";
    }
}
